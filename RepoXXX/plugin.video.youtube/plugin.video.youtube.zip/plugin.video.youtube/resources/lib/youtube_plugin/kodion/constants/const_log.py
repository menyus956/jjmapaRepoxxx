__author__ = 'bromix'

DEBUG = 0
INFO = 2
NOTICE = 2
WARNING = 3
ERROR = 4
SEVERE = 5
FATAL = 6
NONE = 7
